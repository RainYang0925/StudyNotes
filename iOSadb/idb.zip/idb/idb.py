# -*- coding: utf-8 -*-
'''
Created on 2016年6月22日
模仿adb做一个idb
@author: sheldonfan
'''
import sys,os,time
cur_path=os.path.abspath(os.path.dirname(__file__))
sys.path.append(os.path.join(cur_path,"pymobiledevice_sheldonfan"))
from pymobiledevice_sheldonfan.installation_proxy import installation_proxy
from pymobiledevice_sheldonfan.diagnostics_relay import DIAGClient
from pymobiledevice_sheldonfan.afc import AFCShell
from pymobiledevice_sheldonfan.apps import house_arrest
from pymobiledevice_sheldonfan.lockdown import LockdownClient
from pymobiledevice_sheldonfan.logmonitor import LogMonitor
from pymobiledevice_sheldonfan.screenshotr import screenshotr
from pymobiledevice_sheldonfan.traffic import TrafficMonitor 
if __name__ == "__main__":
    
    myarg_len=len(sys.argv)
    if myarg_len==1:
        print "please input argv,look the readme.txt"
        exit()
    
    if sys.argv[1]=="install" and myarg_len==3:
        instpxy = installation_proxy()
        instpxy.install(sys.argv[2])
        instpxy.close()
        exit()
    if sys.argv[1]=="uninstall" and myarg_len==3:
        instpxy = installation_proxy()
        instpxy.uninstall(sys.argv[2])
        instpxy.close()
        exit()
    if sys.argv[1]=="listapps" and myarg_len==2:
        instpxy = installation_proxy()
        instpxy.print_apps(["User","System"])
        instpxy.close()
        exit()
    if sys.argv[1]=="listapps" and myarg_len==3:
        instpxy = installation_proxy()
        if sys.argv[2]=="user":
            instpxy.print_apps(["User"])
            instpxy.close()
            exit()
        if sys.argv[2]=="sys":
            instpxy.print_apps(["System"])
            instpxy.close()
            exit()
    if sys.argv[1]=="reboot" and myarg_len==2:
        dia=DIAGClient()
        dia.restart()
        dia.stop_session()
        exit()
    if sys.argv[1]=="shutdown" and myarg_len==2:
        dia=DIAGClient()
        dia.shutdown()
        dia.stop_session()
        exit()
    if sys.argv[1]=="sleep" and myarg_len==2:
        dia=DIAGClient()
        dia.action("Sleep")
        dia.stop_session()
        exit()
    if sys.argv[1]=="shell" and myarg_len==2:
        AFCShell().cmdloop("Hello iPhone!")
        exit()
    if sys.argv[1]=="pull":
        if myarg_len==2:
            print "please input pull argv,look the readme.txt"
        if myarg_len==3:
            afc=AFCShell().do_pull(sys.argv[2])
        if myarg_len==4:
            afc=AFCShell().do_pull(sys.argv[2]+" "+sys.argv[3]) 
        exit()  
    if sys.argv[1]=="push":
        if myarg_len==4:
            afc=AFCShell().do_push(sys.argv[2]+" "+sys.argv[3]+"/"+os.path.basename(sys.argv[2]))
        else:
            print "please input right argv,look the readme.txt"
        exit()
    if sys.argv[1]=="-p":
        if  myarg_len==6 or myarg_len==5 or myarg_len==4:
            if sys.argv[3]=="pull":
                lockdown = LockdownClient()
                myafc =  house_arrest(lockdown, sys.argv[2])
                if myarg_len==5:
                    AFCShell(client=myafc).do_pull(sys.argv[4])
                if myarg_len==6:
                    AFCShell(client=myafc).do_pull(sys.argv[4]+" "+sys.argv[5])
            if sys.argv[3]=="push":
                lockdown = LockdownClient()
                myafc =  house_arrest(lockdown, sys.argv[2])
                if myarg_len==6:
                    AFCShell(client=myafc).do_push(sys.argv[4]+" "+sys.argv[5]+"/"+os.path.basename(sys.argv[4]).decode("gbk").encode("utf-8"))
                else:
                    print "please input right argv,when some app can not fangwen Sandbox,and tedingde folder can xie file"
            if sys.argv[3]=="shell":
                lockdown = LockdownClient()
                myafc =  house_arrest(lockdown, sys.argv[2])
                if myafc: AFCShell(client=myafc).cmdloop("Hello "+sys.argv[2])
                
                    
        else:
            print "please input right argv,when some app can not fangwen Sandbox"
        if myafc:
            myafc.stop_session()
        exit()
    if sys.argv[1]=="logcat" and myarg_len==2:
        lm=LogMonitor()
        lm.start_toshow()
        while True:
            try:
                time.sleep(0.5)
            except KeyboardInterrupt:
                lm.stop()
                break
        exit()
    if sys.argv[1]=="screenshot" and myarg_len==2:
        screenshotr = screenshotr()    
        data = screenshotr.take_screenshot()
        screenshotr.stop_session()
        if data:
            filename = time.strftime(ur"%Y-%m-%d_%H-%M-%S")+".png"
            outPath = '.'
            outPath = os.path.join(outPath, filename)
            print 'Saving Screenshot at %s' % outPath
            o = open(outPath,'wb')
            o.write(data)
        exit()
    if sys.argv[1]=="pcap":
        
        tm=TrafficMonitor(os.getcwd(),time.strftime(ur"%Y-%m-%d_%H-%M-%S")+".pcap")
    
        logpath=os.path.join(os.getcwd(),time.strftime(ur"%Y-%m-%d_%H-%M-%S")+".log")
        lm=LogMonitor(log_file=logpath)
        lm.start()
        tm.start()
        print 'start capturint flow!'
        print 'press ctrl+c to stop'
        while True:
            try:
                time.sleep(0.5)
            except KeyboardInterrupt:
                print 'stop capturing flow!\n'
                print "Please wait,now is Analysis"
                tm.stop()
                lm.stop()
                
                
                print "total traffic is:"+str(tm.flow_list)
                #result_all=analysis("6.5","mobile_info","pcap_newmonkey2",1,os.path.join(tm.file_path,tm.file_name),1,{},tool_name="pcap_newmonkey2")["report_url"]
                #webbrowser.open_new_tab(result_all)
                break
        