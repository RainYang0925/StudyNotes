# -*- coding: utf-8 -*-
'''
Created on 2016年5月4日

@author: sheldonfan
'''
import time,threading
from basemonitor import Monitor
from syslog import Syslog

class LogMonitor(Monitor):
    def __init__(self,udid=None, log_file = 'mylog.log'):
        
        self.file=log_file
        self._log=Syslog()
    def start_getfile(self):
        self._log.watch(logFile=self.file)
    #新增的用于展示的接口
    def toshow(self):
        self._log.watch2()
    def start(self):
        start_time = time.time()
        th = threading.Thread(target = self.start_getfile)
        th.setDaemon(True)
        try:
            th.start()
            start_time = time.time()
        except:
            pass
    #新增的用户展示的
    def start_toshow(self):
        start_time = time.time()
        th = threading.Thread(target = self.toshow)
        th.setDaemon(True)
        try:
            th.start()
            start_time = time.time()
        except:
            pass
    def stop(self):
        #使用标记位停止抓取日志
        self._log.stop_flag=True
        self._log.__del__()