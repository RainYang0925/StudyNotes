# -*- coding: utf-8 -*-
'''流量监视器
'''
import os
from pcapd import PcapOut
import time
import struct


from basemonitor import Monitor
from lockdown import LockdownClient

import shutil
import threading

lock = threading.Lock()
class PcapdWrapper(object):
    '''
        正在负责抓包和解包的类
    '''
    def __init__(self,udid, pcap_file = 'traffic.pcap'):
        '''请求com.apple.pcapd服务
        '''
        self.tcpdump_pids = []
        self.rvictl_success = False
        self.pcap_file = pcap_file
        self.flow = 0
        self.stop = False
        retry_count = 10
        while retry_count > 0:
            try:
                self.pcap = LockdownClient(udid).startService("com.apple.pcapd")
                break
            except:
                retry_count -= 1
        if not hasattr(self,'pcap'):
            raise RuntimeError(u'Start com.apple.pcapd failed')

    def start_package_capture(self):
        '''开始抓包
        '''
        self.stop = False
        print "Enter start_package_capture:%s " % self.stop
        self.output = PcapOut(self.pcap_file)
        # if sys.platform == "win32":
        #     output = PcapOut(self.pcap_file)
        # elif sys.platform == "darwin":
        #     output = PcapOut(self.pcap_file)
        # else:
        #     output = PcapOut()
        self.flow = 0
        count = 0

        self.flow = 0
        if lock.locked(): lock.release()
        while True:
            while True:
                d = self.pcap.recvPlist()
                if d or self.stop:
                    break
            if self.stop:
                print "************Stop*************"
                if lock.locked:
                    lock.release()
                break
            data = d.data
            hdrsize, xxx, packet_size = struct.unpack(">LBL", data[:9])
            flags1, flags2, offset_to_ip_data, zero = struct.unpack(">LLLL", data[9:0x19])
            assert hdrsize >= 0x19
            interfacetype= data[0x19:hdrsize].strip("\x00")
            t = time.time()
            if not self.stop:
                #print "self.flow:%d,packet_size:%s" % (self.flow,packet_size)
                self.flow += packet_size
            if not lock.locked(): lock.acquire()
            packet = data[hdrsize:]
            assert packet_size == len(packet)
            if offset_to_ip_data == 0:
                packet = "\xBE\xEF" * 6 + "\x08\x00" + packet
            count += 1

            if not self.output.writePacket(packet):
                self.pcap.close()
                break

    def stop_package_capture(self, dst_file):
        '''
            结束抓包,拷贝pcap文件后删除

            :param str dst_file: 将生成的pcap文件拷贝到该路径下
            :return: 返回流量值
            :rtype: int
        '''

        self.stop = True
        lock.acquire()
        """
        dst_file = os.path.join(dst_file, os.path.basename(self.pcap_file))
        try:
            shutil.copyfile(self.pcap_file, dst_file)
            os.remove(self.pcap_file)
        except:
            import traceback
            traceback.print_exc()
        """
        self.pcap.close()
        self.output.__del__()
        return self.flow
    
    def __del__(self):
        print "traffic del"
        self.pcap.close()


class TrafficMonitor(Monitor):
    '''
        解析trace获取整机流量
    '''
    def __init__(self,file_path,filename="traffic.pcap",udid=None):
        '''

            :param str file_path: trace文件路径
        '''
        self.file_path  = file_path
        self.file_name  = filename
        self.p = PcapdWrapper(udid=udid,pcap_file=self.file_name)
        self.network_type = ''
        self.flow_list= []
        lock.acquire()

    def start(self):
        '''
            抓包放在子线程，使用者可以使用stop接口来结束抓包
        '''
        start_time = time.time()
        th = threading.Thread(target = self.p.start_package_capture)
        th.setDaemon(True)
        try:
            th.start()
            start_time = time.time()
        except:
            pass
        lock.acquire()

    def stop(self):
        '''
            结束抓包，拷贝pcap并删除
        '''
        flow = self.p.stop_package_capture(self.file_path)
        if flow:
            self.flow_list.append(flow)

    def get_flow(self):
        '''
            结束流量监视器后,调用此接口返回本次测试的总流量
        '''
        return self.flow_list
    
    def save(self, session):
        '''

        :param Session session: 存放文件的session对象
        :return: 返回文件路径
        :rtype: str
        '''
        return session.move_to_session(os.path.join(self.file_path,self.file_name))

if __name__ == '__main__':
    tm = TrafficMonitor(r'D:\\')
    tm.start()
    print 'start capturint flow!'
    print 'press ctrl+c to stop'
    while True:
        try:
            time.sleep(0.5)
        except KeyboardInterrupt:
            print 'stop capturing flow!\n'
            print "Please wait,now is Analysis"
            tm.stop()
            break
